# Topics

Assignment1:  
* Install Jenkins using package.
* Run jenkins war on the top of a tomcat server.

Assignment2:
* Install any five plugin and use them.
* Install a plugin manually.

Assignment3:
* Create a freestyle job to print "Hello world".
* Create a freestyle job to which take absolute path of a directory then
     1. List all files and directories inside that. 
     2. Print a message "drectory not exist" if directory doesn't exist on file system
     3. Print "Inappropriate permissions" if you don't have permissions to list files. 
* Create a job to clone your jenkins repo and cat a file from it. 
* Create tag using git plugin.

Assignment4:
* Increase and decrease number of executors and observe the build queue.
 
