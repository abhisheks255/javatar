# Topics

Assignment1:  
* Setup unix based authentication.
* Configure Matrix based authorization.
* Implement project based matrix based authorization.
* Configure SSO using gmail based login.
* Setup a role based user authentication and autharization.



Assignment2: 
* Setup email notification for each job failure only.
* Send jenkins console logs in mail not as attachement but as plain text. 
* Enable slack integration for jenkins jobs build notifications.

Assignment3: 
* Add a slave to your jenkins, restrict some of the job to your slave. 


